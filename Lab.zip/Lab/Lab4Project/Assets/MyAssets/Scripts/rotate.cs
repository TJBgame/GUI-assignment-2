﻿using UnityEngine;
using System.Collections;

public class rotate : MonoBehaviour {


	private GameObject center;
	public int speed = 3;

	// Use this for initialization
	void Start () {
		center = GameObject.Find ("turret/base");
	}
	
	// Update is called once per frame
	void Update () {
		transform.RotateAround (center.transform.position, Vector3.back, 20*speed*Time.deltaTime);
	}
}
