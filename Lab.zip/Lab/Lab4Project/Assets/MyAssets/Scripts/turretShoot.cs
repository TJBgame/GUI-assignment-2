﻿using UnityEngine;
using System.Collections;

public class turretShoot : MonoBehaviour {

	private float fire;
	private float delay;
	public int delayFrom = 1;
	public int delayTo = 3;
	private int gunBack = 1;

	[SerializeField] private GameObject enemyBullet;
	[SerializeField] private GameObject gun;

	// Use this for initialization
	void Start () {
		fire = Random.Range (delayFrom, delayTo);
	}

	// Update is called once per frame
	void Update () {
		fire -= Time.deltaTime;
		if (fire <= 0){
			delay = Random.Range (delayFrom, delayTo);
			fire = delay;
			enemyFire ();
			back ();
		}
		if (gunBack == 2) {
			StartCoroutine (gunReturn ());
		}
	}

	private IEnumerator gunReturn(){
		gunBack = 1;
		yield return new WaitForSeconds (0.5f);
		gun.transform.Translate (0, 1, 0);
	}

	private void enemyFire(){
		GameObject enemyBullets = Instantiate (enemyBullet) as GameObject;

		//set the instantiate position.
		enemyBullets.transform.position = this.transform.position;
		enemyBullets.transform.rotation = this.transform.rotation;
	}
	private void back(){
		gun.transform.Translate (0, -1, 0);
		gunBack = 2;
	}
}
