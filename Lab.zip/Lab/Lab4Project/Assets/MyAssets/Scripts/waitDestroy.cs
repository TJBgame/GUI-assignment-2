﻿using UnityEngine;
using System.Collections;

public class waitDestroy : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		StartCoroutine (wait ());
	}
	private IEnumerator wait(){
		yield return new WaitForSeconds (0.333f);
		Destroy (this.gameObject);
	}
}
