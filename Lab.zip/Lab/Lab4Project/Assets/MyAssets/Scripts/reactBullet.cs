﻿using UnityEngine;
using System.Collections;

public class reactBullet : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		StartCoroutine (wait ());
	}
	void OnTriggerEnter2D (Collider2D hit) {
		
		if (hit.gameObject.tag == "Wall") {
			Destroy (this.gameObject);
		}

		if (hit.gameObject.tag == "player") {
			Destroy (this.gameObject);
		}
	}
	private IEnumerator wait(){
		yield return new WaitForSeconds (5f);
		Destroy (this.gameObject);
	}
}
