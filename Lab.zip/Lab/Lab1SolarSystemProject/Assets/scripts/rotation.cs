﻿using UnityEngine;
using System.Collections;

public class rotation : MonoBehaviour {

	public GameObject star;
	public int speed = 3;


	// Use this for initialization
	void Start () {
		star = GameObject.Find ("Sun");
	}
	
	// Update is called once per frame
	void Update () {
		transform.RotateAround (star.transform.position, Vector3.up, 20*speed*Time.deltaTime);
	}
}
