﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class loadScene : MonoBehaviour {

	public string levelName = "1";

	void OnEnable(){
		if (levelName == "1") {
			SceneManager.LoadScene ("Scene2");
			levelName = "2";
		}
		else{
			SceneManager.LoadScene("Scene1");
		}
	}

	void Awake(){
		this.enabled = false;
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
