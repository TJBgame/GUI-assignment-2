﻿using UnityEngine;
using System.Collections;

public class translation : MonoBehaviour {

	public int speed = 3;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (Vector3.right * speed * Time.deltaTime);
	}
}
