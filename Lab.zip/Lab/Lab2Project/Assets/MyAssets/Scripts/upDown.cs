﻿using UnityEngine;
using System.Collections;

public class upDown : MonoBehaviour {
		public float speed = 30f;
		public float max = 90;
		private float angle;
		//private GameObject center;

	// Use this for initialization
	void Start () {
				//center = GameObject.Find ("Turret/turret base/gun/center");
	}
	
	// Update is called once per frame
	void Update () {
				if (Input.GetKey (KeyCode.UpArrow)) {
						transform.Rotate (0, 0, speed * Time.deltaTime);
					}
				if (Input.GetKey (KeyCode.DownArrow)) {
						transform.Rotate (0, 0, -speed * Time.deltaTime);
					}
				if (transform.localEulerAngles.z > 180) {
						Quaternion quate = Quaternion.identity;
						quate.eulerAngles = new Vector3(0, 0, 0);
						transform.rotation = quate;
				}
				if (transform.localEulerAngles.z > 90 && transform.localEulerAngles.z < 180) {
						Quaternion quate = Quaternion.identity;
						quate.eulerAngles = new Vector3 (0, 0, 90);
						transform.rotation = quate;
				}
	}
}
