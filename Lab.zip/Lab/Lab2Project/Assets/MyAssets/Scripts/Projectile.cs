﻿using UnityEngine;
using System.Collections;

public class Projectile : MonoBehaviour {

		[SerializeField] private GameObject bullet;
		private GameObject pos;
		private GameObject obj;
		private int coolDown = 1;

	// Use this for initialization
	void Start () {
				pos = GameObject.Find ("Turret/turret base/turret gun/pos");
	}
	
	// Update is called once per frame
	void Update () {
				if (Input.GetKey (KeyCode.Space) && coolDown == 1) {
						coolDown = 2;
						GameObject bullets = Instantiate (bullet) as GameObject;
						bullets.transform.position = pos.transform.position;
						bullets.transform.rotation = pos.transform.rotation;
						StartCoroutine (coolDownFunction ());
				}
	}
		private IEnumerator coolDownFunction(){
				yield return new WaitForSeconds (0.15f);
				coolDown = 1;
		}
}
