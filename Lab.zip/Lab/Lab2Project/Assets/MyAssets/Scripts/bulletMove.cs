﻿using UnityEngine;
using System.Collections;

public class bulletMove : MonoBehaviour {
		public float speed = 10f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
				transform.Translate (Vector3.right*speed*Time.deltaTime);
				StartCoroutine (delay ());
	}
		private IEnumerator delay(){
				yield return new WaitForSeconds (10f);

				Destroy (this.gameObject);
		}
}
