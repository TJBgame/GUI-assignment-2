"use strict";

var canvas;
var gl;

var NumVertices  = 252;
var xOffset=0;
var yOffset=0;
var zOffset=0;
var togglerotate=1;

var points = [];
var colors = [];

var xAxis = 0;
var yAxis = 1;
var zAxis = 2;

var axis = 1;
var theta = [ 14, 140, 0 ];
//var theta = [ 0, 0, 0 ];

var thetaLoc;

window.onload = function init()
{
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    xOffset=0.0;
    yOffset=0.21;
    zOffset=0.0;
    colorCube();

    xOffset=-0.0;
    yOffset=0.13;
    zOffset=0.0;
    colorTableTop();

    xOffset=0.290;
    yOffset=-0.04;
    zOffset=0.29;
    colorTableLeg();


    xOffset=0.290;
    yOffset=-0.04;
    zOffset=-0.29;
    colorTableLeg();


    xOffset=-0.290;
    yOffset=-0.04;
    zOffset=-0.29;
    colorTableLeg();

    xOffset=-0.290;
    yOffset=-0.04;
    zOffset=0.29;
    colorTableLeg();

    xOffset=-0.0;
    yOffset=-0.19;
    zOffset=0.0;
    colorFloor();



    bufferinit();
    eventlistenButton();
    render();
}

function eventlistenButton() {

    document.getElementById( "xButton" ).onclick = function () {
togglerotate=1;
        axis = xAxis;
    };
    document.getElementById( "yButton" ).onclick = function () {
togglerotate=1;
        axis = yAxis;
    };
    document.getElementById( "zButton" ).onclick = function () {
togglerotate=1;
        axis = zAxis;
    };
    document.getElementById( "ToggleButton" ).onclick = function () {
        if (togglerotate==1){
           togglerotate=0;}
        else{
           togglerotate=1;}
    };



}





function bufferinit() {

gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    var program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );

    var vColor = gl.getAttribLocation( program, "vColor" );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vColor );

    var vBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, vBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW );


    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );

    thetaLoc = gl.getUniformLocation(program, "theta");

}


function colorTableTop()
{
    quadTableTop( 1, 0, 3, 2 );
    quadTableTop( 2, 3, 7, 6 );
    quadTableTop( 3, 0, 4, 7 );
    quadTableTop( 6, 5, 1, 2 );
    quadTableTop( 4, 5, 6, 7 );
    quadTableTop( 5, 4, 0, 1 );
}

function quadTableTop(a, b, c, d)
{
    var vertices = [
        vec4( -0.3+xOffset, -0.02+yOffset,  0.3+zOffset, 1.0 ),
        vec4( -0.3+xOffset,  0.02+yOffset,  0.3+zOffset, 1.0 ),
        vec4(  0.3+xOffset,  0.02+yOffset,  0.3+zOffset, 1.0 ),
        vec4(  0.3+xOffset, -0.02+yOffset,  0.3+zOffset, 1.0 ),
        vec4( -0.3+xOffset, -0.02+yOffset, -0.3+zOffset, 1.0 ),
        vec4( -0.3+xOffset,  0.02+yOffset, -0.3+zOffset, 1.0 ),
        vec4(  0.3+xOffset,  0.02+yOffset, -0.3+zOffset, 1.0 ),
        vec4(  0.3+xOffset, -0.02+yOffset, -0.3+zOffset, 1.0 )
    ];

    var vertexColors = [
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ]   // yellowish brown
    ];

    // We need to parition the quad into two triangles in order for
    // WebGL to be able to render it.  In this case, we create two
    // triangles from the quad indices

    //vertex color assigned by the index of the vertex

    var indices = [ a, b, c, a, c, d ];

    for ( var i = 0; i < indices.length; ++i ) {
        points.push( vertices[indices[i]] );
        //colors.push( vertexColors[indices[i]] );

        // for solid colored faces use
        colors.push(vertexColors[a]);

    }
}




function colorFloor()
{
    quadFloor( 1, 0, 3, 2 );
    quadFloor( 2, 3, 7, 6 );
    quadFloor( 3, 0, 4, 7 );
    quadFloor( 6, 5, 1, 2 );
    quadFloor( 4, 5, 6, 7 );
    quadFloor( 5, 4, 0, 1 );
}

function quadFloor(a, b, c, d)
{
    var vertices = [
        vec4( -0.6+xOffset, -0.001+yOffset,  0.6+zOffset, 1.0 ),
        vec4( -0.6+xOffset,  0.001+yOffset,  0.6+zOffset, 1.0 ),
        vec4(  0.6+xOffset,  0.001+yOffset,  0.6+zOffset, 1.0 ),
        vec4(  0.6+xOffset, -0.001+yOffset,  0.6+zOffset, 1.0 ),
        vec4( -0.6+xOffset, -0.001+yOffset, -0.6+zOffset, 1.0 ),
        vec4( -0.6+xOffset,  0.001+yOffset, -0.6+zOffset, 1.0 ),
        vec4(  0.6+xOffset,  0.001+yOffset, -0.6+zOffset, 1.0 ),
        vec4(  0.6+xOffset, -0.001+yOffset, -0.6+zOffset, 1.0 )
    ];

    var vertexColors = [
        [ 1.0, 0.0, 0.2, 0.8  ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8  ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8 ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8  ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8  ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8 ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8  ],  // magenta
        [ 1.0, 0.0, 0.2, 0.8  ]   // magenta
    ];

    // We need to parition the quad into two triangles in order for
    // WebGL to be able to render it.  In this case, we create two
    // triangles from the quad indices

    //vertex color assigned by the index of the vertex

    var indices = [ a, b, c, a, c, d ];

    for ( var i = 0; i < indices.length; ++i ) {
        points.push( vertices[indices[i]] );
        //colors.push( vertexColors[indices[i]] );

        // for solid colored faces use
        colors.push(vertexColors[a]);

    }
}








function colorCube()
{
    quad( 1, 0, 3, 2 );
    quad( 2, 3, 7, 6 );
    quad( 3, 0, 4, 7 );
    quad( 6, 5, 1, 2 );
    quad( 4, 5, 6, 7 );
    quad( 5, 4, 0, 1 );
}

function quad(a, b, c, d)
{
    var vertices = [
        vec4( -0.06+xOffset, -0.06+yOffset,  0.06+zOffset, 1.0 ),
        vec4( -0.06+xOffset,  0.06+yOffset,  0.06+zOffset, 1.0 ),
        vec4(  0.06+xOffset,  0.06+yOffset,  0.06+zOffset, 1.0 ),
        vec4(  0.06+xOffset, -0.06+yOffset,  0.06+zOffset, 1.0 ),
        vec4( -0.06+xOffset, -0.06+yOffset, -0.06+zOffset, 1.0 ),
        vec4( -0.06+xOffset,  0.06+yOffset, -0.06+zOffset, 1.0 ),
        vec4(  0.06+xOffset,  0.06+yOffset, -0.06+zOffset, 1.0 ),
        vec4(  0.06+xOffset, -0.06+yOffset, -0.06+zOffset, 1.0 )
    ];

    var vertexColors = [
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ],  // blue
        [ 0.4, 0.0, 1.0, 0.7 ]   // blue
    ];

    
    var indices = [ a, b, c, a, c, d ];

    for ( var i = 0; i < indices.length; ++i ) {
        points.push( vertices[indices[i]] );
        //colors.push( vertexColors[indices[i]] );
        colors.push(vertexColors[a]);

    }
}


function colorTableLeg()
{
    quadTableLeg( 1, 0, 3, 2 );
    quadTableLeg( 2, 3, 7, 6 );
    quadTableLeg( 3, 0, 4, 7 );
    quadTableLeg( 6, 5, 1, 2 );
    quadTableLeg( 4, 5, 6, 7 );
    quadTableLeg( 5, 4, 0, 1 );
}

function quadTableLeg(a, b, c, d)
{
    var vertices = [
        vec4( -0.01+xOffset, -0.15+yOffset,  0.01+zOffset, 1.0 ),
        vec4( -0.01+xOffset,  0.15+yOffset,  0.01+zOffset, 1.0 ),
        vec4(  0.01+xOffset,  0.15+yOffset,  0.01+zOffset, 1.0 ),
        vec4(  0.01+xOffset, -0.15+yOffset,  0.01+zOffset, 1.0 ),
        vec4( -0.01+xOffset, -0.15+yOffset, -0.01+zOffset, 1.0 ),
        vec4( -0.01+xOffset,  0.15+yOffset, -0.01+zOffset, 1.0 ),
        vec4(  0.01+xOffset,  0.15+yOffset, -0.01+zOffset, 1.0 ),
        vec4(  0.01+xOffset, -0.15+yOffset, -0.01+zOffset, 1.0 )
    ];

    var vertexColors = [
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ],  // yellowish brown
        [ 0.5, 0.5, 0.0, 0.7 ]   // yellowish brown
    ];

    
    var indices = [ a, b, c, a, c, d ];

    for ( var i = 0; i < indices.length; ++i ) {
        points.push( vertices[indices[i]] );
        //colors.push( vertexColors[indices[i]] );
        colors.push(vertexColors[a]);

    }
}











function render()
{
    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);


   if (togglerotate==1){
    theta[axis] += 1.0;
   }
    gl.uniform3fv(thetaLoc, theta);

    gl.drawArrays( gl.TRIANGLES, 0, NumVertices );


    requestAnimFrame( render );
}
