var gl;
var canvas;

var shaderProgram;

var tableVertexPositionBuffer;
var tableVertexIndexBuffer;

var LegVertexPositionBuffer;
var LegVertexIndexBuffer;

var modelViewMatrix;
var projectionMatrix;
var modelViewMatrixStack;

var axis = 0;
var xAxis = 0;
var yAxis =1;
var zAxis = 2;
var theta = [ 0, 0, 0 ];
var thetaLoc;
var stop = 1;



window.onload = function init(){
  canvas = document.getElementById( "gl-canvas" );
  gl = WebGLDebugUtils.makeDebugContext(createGLContext(canvas));

  setupShaders();
  setupBuffers();

  gl.clearColor(0.8, 0.8, 0.8, 1.0);
  gl.enable(gl.DEPTH_TEST);
    
    
  document.getElementById( "xButton" ).onclick = function () {

      stop = 1;
      axis = xAxis;

  };

  document.getElementById( "yButton" ).onclick = function () {
      
      stop = 1;
      axis = yAxis;

  };

  document.getElementById( "zButton" ).onclick = function () {

      stop = 1;
      axis = zAxis;

  };
    
  document.getElementById( "stopButton" ).onclick = function () {

      if(stop==1){
          stop = 2;
      }
      else{
          stop =1;
      }

  };
    

    
  draw();
}



function createGLContext(canvas) {

  var names = ["webgl", "experimental-webgl"];

  var context = null;

  for (var i=0; i < names.length; i++) {

    try {

      context = canvas.getContext(names[i]);

    } catch(e) {}

    if (context) {

      break;

    }

  }

  if (context) {

    context.viewportWidth = canvas.width;

    context.viewportHeight = canvas.height;

  } else {

    alert("Failed to create WebGL context!");

  }

  return context;

}





function setupShaders() {
 shaderProgram = initShaders( gl, "vertex-shader", "fragment-shader" );

  gl.useProgram( shaderProgram );



  shaderProgram.vertexPositionAttribute = gl.getAttribLocation(shaderProgram, "aVertexPosition");

  shaderProgram.vertexColorAttribute = gl.getAttribLocation(shaderProgram, "aVertexColor");

  shaderProgram.uniformMVMatrix = gl.getUniformLocation(shaderProgram, "uMVMatrix");

  shaderProgram.uniformProjMatrix = gl.getUniformLocation(shaderProgram, "uPMatrix");

  gl.enableVertexAttribArray( shaderProgram.vertexPositionAttribute );



  modelViewMatrix = mat4.create();

  projectionMatrix = mat4.create();

  modelViewMatrixStack = [];
}





function setuptableBuffers() {

  tableVertexPositionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, tableVertexPositionBuffer);

  var tableVertexPosition = [
       6.0,  -1.0,  6.0,

       6.0,  -1.0, -6.0,

      -6.0,  -1.0, -6.0,

      -6.0,  -1.0,  6.0
  ];

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(tableVertexPosition), gl.STATIC_DRAW);
  tableVertexPositionBuffer.itemSize = 3;
  tableVertexPositionBuffer.numberOfItems = 4;

  tableVertexIndexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, tableVertexIndexBuffer);

  var tableVertexIndices = [0, 1, 2, 3];

  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(tableVertexIndices), gl.STATIC_DRAW);
  tableVertexIndexBuffer.itemSize = 1;
  tableVertexIndexBuffer.numberOfItems = 4;
    
  thetaLoc = gl.getUniformLocation(shaderProgram, "theta");
}



function setupLegBuffers() {

  LegVertexPositionBuffer = gl.createBuffer();

  gl.bindBuffer(gl.ARRAY_BUFFER, LegVertexPositionBuffer);

  var LegVertexPosition = [
       
        //front
        3.0,  2.0,  3.0,
        3.0,  -1.0,  3.0,
        2.6,  -1.0,  3.0,
        2.6,  2.0,  3.0,
        
        //right
        3.0,  2.0,  3.0,
        3.0,  -1.0,  3.0,
        3.0,  -1.0,  2.6,
        3.0,  2.0,  2.6,
        
        //back
        3.0,  2.0,  2.6,
        3.0,  -1.0,  2.6,
        2.6,  -1.0,  2.6,
        2.6,  2.0,  2.6,
        
        //left
        2.6,  2.0,  2.6,
        2.6,  -1.0,  2.6,
        2.6,  -1.0,  3.0,
        2.6,  2.0,  3.0,
        
        //bottom
        3.0,  0.0,  3.0,
        3.0,  -1.0,  2.6,
        2.6,  -1.0,  2.6,
        2.6,  -1.0,  3.0

  ];

  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(LegVertexPosition), gl.STATIC_DRAW);

  LegVertexPositionBuffer.itemSize = 3;
  LegVertexPositionBuffer.numberOfItems = 20;

  LegVertexIndexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, LegVertexIndexBuffer);

  var LegVertexIndices = [

            0, 1, 2,      0, 2, 3,

            4, 6, 5,      4, 7, 6, 

            8, 9, 10,     8, 10, 11, 

            12, 13, 14,   12, 14, 15,

            16, 17, 18,   16, 18, 19, 

        ];

  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(LegVertexIndices), gl.STATIC_DRAW);

  LegVertexIndexBuffer.itemSize = 1;
  LegVertexIndexBuffer.numberOfItems = 30;
    
  thetaLoc = gl.getUniformLocation(shaderProgram, "theta");

}

function setupBuffers() {

  setuptableBuffers();
  setupLegBuffers();

}

function uploadModelViewMatrixToShader() {
  gl.uniformMatrix4fv(shaderProgram.uniformMVMatrix, false, modelViewMatrix);

}

function uploadProjectionMatrixToShader() {
  gl.uniformMatrix4fv(shaderProgram.uniformProjMatrix,false, projectionMatrix);
}



function drawtable(r,g,b,a) {
  gl.disableVertexAttribArray(shaderProgram.vertexColorAttribute);
  gl.vertexAttrib4f(shaderProgram.vertexColorAttribute, r, g, b, a);

  gl.bindBuffer(gl.ARRAY_BUFFER, tableVertexPositionBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, tableVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, tableVertexIndexBuffer);
  gl.drawElements(gl.TRIANGLE_FAN, tableVertexIndexBuffer.numberOfItems, gl.UNSIGNED_SHORT, 0);
}



function drawLeg(r,g,b,a) {
  gl.disableVertexAttribArray(shaderProgram.vertexColorAttribute);
  gl.vertexAttrib4f(shaderProgram.vertexColorAttribute, r, g, b, a);

  gl.bindBuffer(gl.ARRAY_BUFFER, LegVertexPositionBuffer);
  gl.vertexAttribPointer(shaderProgram.vertexPositionAttribute, LegVertexPositionBuffer.itemSize, gl.FLOAT, false, 0, 0);
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, LegVertexIndexBuffer);

  gl.drawElements(gl.TRIANGLES, LegVertexIndexBuffer.numberOfItems, gl.UNSIGNED_SHORT, 0);
}





function draw() {
    
    gl.viewport(0, 0, gl.viewportWidth, gl.viewportHeight);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  
    mat4.perspective(70, gl.viewportWidth / gl.viewportHeight, 0.1, 100.0, projectionMatrix);
    mat4.identity(modelViewMatrix);
  
  
    mat4.lookAt([10, -15, 20],[0, 0, 0], [0, 1, 0], modelViewMatrix);
    

    
    //floor
    uploadModelViewMatrixToShader();
    uploadProjectionMatrixToShader();

    drawtable(1, 0.5, 0.5, 1.0);

    //leg one
    drawLeg(0.4, 0.6, 0.0, 1.0);

    //leg two
    mat4.translate(modelViewMatrix, [0.0, 0.0 ,-5.6], modelViewMatrix);
    uploadModelViewMatrixToShader();

    drawLeg(0.4, 0.6, 0.0, 1);

    //leg three
    mat4.translate(modelViewMatrix, [-5.6, 0.0 ,0.0], modelViewMatrix);
    uploadModelViewMatrixToShader();

    drawLeg(0.4, 0.6, 0.0, 1);

    //leg four
    mat4.translate(modelViewMatrix, [0.0, 0.0 ,5.6], modelViewMatrix);
    uploadModelViewMatrixToShader();

    drawLeg(0.4, 0.6, 0.0, 1);

    //table
    mat4.translate(modelViewMatrix, [-46, 2.1 ,-51.5], modelViewMatrix);
    mat4.scale(modelViewMatrix, [18.5, 0.1, 18.5], modelViewMatrix);
    uploadModelViewMatrixToShader();

    drawLeg(1.0, 0.7, 0.0, 1);

    //box
    mat4.translate(modelViewMatrix, [2.3, 5 ,2.3], modelViewMatrix);
    mat4.scale(modelViewMatrix, [0.2, 5, 0.2], modelViewMatrix);
    uploadModelViewMatrixToShader();

    drawLeg(0, 0.7, 1, 1);




    
    if(stop ==1){
    theta[axis] += 2.0;
    gl.uniform3fv(thetaLoc, theta);
    }
    
    requestAnimFrame( draw );
    
}
